@echo off
chcp 65001 >nul
REM ========================================
REM Script: Atualizar Branch Atual
REM Versao: 3.1 - DEFINITIVA
REM ========================================

echo.
echo ========================================
echo   ATUALIZANDO BRANCH ATUAL
echo ========================================
echo.

REM Pegar branch atual
for /f "tokens=*" %%i in ('git rev-parse --abbrev-ref HEAD') do set BRANCH=%%i

echo Branch atual: %BRANCH%
echo.

REM Verificar se tem alterações não salvas
git diff --quiet
if errorlevel 1 (
    echo [AVISO] Voce tem alteracoes nao salvas!
    echo.
    git status --short
    echo.
    set /p SAVE="Deseja salvar antes de atualizar? (S/N): "
    if /i "%SAVE%"=="S" (
        echo.
        echo Salvando alteracoes...
        git add .
        git commit -m "WIP: Salvando antes de atualizar"
        if errorlevel 1 (
            echo [ERRO] Falha ao salvar alteracoes!
            pause
            exit /b 1
        )
    )
)

echo Baixando atualizacoes do GitHub...
git pull origin %BRANCH%

if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao atualizar!
    echo.
    echo Possiveis causas:
    echo - Sem conexao com internet
    echo - Branch nao existe no GitHub
    echo - Conflitos locais
    echo.
    echo Execute: git status (para ver o problema)
) else (
    echo.
    echo ========================================
    echo   BRANCH ATUALIZADA COM SUCESSO!
    echo ========================================
    echo.
    echo Branch: %BRANCH%
    echo Seus arquivos locais estao sincronizados.
)

echo.
pause
